# M8 subset 2 review

Added executor death and freezing to the isolated chaos suite. All three current
scenarios passed twice consecutively. Subset 3 has not been implemented; the
seven-scenario ten-pass M8 acceptance remains pending.

## Behavior and runtime fix

- Kill: hold HTTP attempt 1, identify its owning executor using worker hostname
  and Docker labels, disable restart, and send SIGKILL. Require attempt 2 to
  succeed on another executor within 20 seconds, then restore the original
  restart policy and three live workers.
- Freeze: pause the owner for 25 seconds and require attempt 2 to succeed before
  resuming it. Verify the old worker's self-fencing log, a fresh live identity on
  the same hostname, and unchanged winning run/attempt history after releasing
  the held response.
- Both scenarios retain one run/fire and two attempts: FAILED from lease expiry,
  then SUCCEEDED. Both HTTP calls carry the run ID as their idempotency key and
  attempt headers 1 and 2. The fixture records both calls without deduplicating
  side effects. No stale-counter increase is required.
- Worker inspection stays behind the chaos tag. Cleanup now restores disabled
  executor policies and starts victims even if the runner is lost.

The first real kill test failed at the 20-second deadline: Postgres had recovered
attempt 2, but it remained QUEUED because Kafka still assigned its run-ID partition
to the dead consumer. `pkg/worker` now explicitly uses a **10-second Kafka session
timeout**, replacing kafka-go's 30-second default. This is the only production
change. Kafka heartbeat, database lease/heartbeat, public APIs, and schemas stay
unchanged. Broker policy must accept 10-second sessions; consumer reassignment
now starts sooner after missed heartbeats.

## Validation on 2026-10-14

| Check | Result |
| --- | --- |
| Original Kafka settings, real executor kill | Failed at 20s with attempt 2 QUEUED; retained as regression evidence |
| `go test -race -count=1 ./...` after the fix | Passed |
| Race-enabled fixture/scope checks | Passed; attempt 2 completes independently of held attempt 1 |
| Seven relevant race-enabled integration tests | Passed |
| `make chaos` after the fix | All three scenarios passed |
| Final `make chaos CHAOS_COUNT=2` | Six scenario executions passed |
| Runner SIGKILL after executor death with restart disabled | Expected exit 137; host restored the policy and started the victim before teardown |
| Shell lifecycle checks, Bash syntax, diff whitespace | Passed |

The integration filter covers the public worker runtime, HTTP retry identity and
timing, retry/cancel outcomes, self-fencing, recovery to another executor, and
fencing after lock waits. Disposable testcontainers were used through the Go
container with host-gateway endpoint resolution.

Final kill recovery times were **14.66s and 19.18s**, measured from SIGKILL to the
verified successful retry. Overall test duration also includes setup and worker
restoration. Both freezes lasted at least 25 seconds, produced the old worker's
self-fencing log, and retained exactly one SUCCEEDED attempt. Six metric snapshots
and worker histories were saved per scenario. Development and benchmark container
identities/states matched their pre-validation inventory, and chaos resources
were removed.

## Evidence and review gate

[subset2-evidence.tar.gz](subset2-evidence.tar.gz) contains the original failed
run, the first fixed run, the final two-pass run, the interrupted restoration
probe, unit/integration/shell logs, inventories, and the production fix diff.
`checks/executor-restoration-probe.sh` reproduces the interruption check when
invoked from the repository root.

Local runs:

- Before fix: `results/20261014T160411Z-5O27m4`
- First fixed pass: `results/20261014T160814Z-kgDaOo`
- Runner-loss restoration: `results/20261014T161409Z-xv3slZ`
- Final two-pass run: `results/20261014T161630Z-hKd5Ng`

Stop here for subset 2 review. Dependency restarts, Redis outage, watcher death,
and full repeated M8 acceptance require the next go-ahead.
