#!/usr/bin/env bash
set -euo pipefail
[[ -f scripts/chaos.sh && -f docker-compose.chaos.yml ]]
probe_dir=$(mktemp -d /tmp/m8-subset2-cleanup-XXXXXX)
echo "Executor restoration probe: $probe_dir"
inventory() {
  docker ps -a --no-trunc --format '{{.ID}} {{.Names}} {{.State}}' | rg ' (distributed_job_scheduler|scheduler-bench)-' | sort
}
inventory > "$probe_dir/before.txt"
timeout 240 docker events --filter type=container --filter event=kill \
  --filter label=com.docker.compose.project=scheduler-chaos \
  --filter label=com.docker.compose.service=executor --format '{{.Actor.ID}}' > "$probe_dir/kill.events" &
events_pid=$!
bash scripts/chaos.sh > "$probe_dir/host.log" 2>&1 &
harness_pid=$!
cleanup() {
  trap - EXIT
  kill "$events_pid" 2>/dev/null || true
  if kill -0 "$harness_pid" 2>/dev/null; then
    kill -TERM "$harness_pid" || true
    wait "$harness_pid" || true
  fi
}
trap cleanup EXIT
started=$SECONDS
until [[ -s "$probe_dir/kill.events" ]]; do
  if ! kill -0 "$harness_pid" 2>/dev/null || (( SECONDS - started >= 240 )); then
    tail -n 30 "$probe_dir/host.log"
    exit 1
  fi
  sleep 0.05
done
read -r victim_id < "$probe_dir/kill.events"
labels=$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}} {{index .Config.Labels "com.docker.compose.service"}} {{.HostConfig.RestartPolicy.Name}}' "$victim_id")
[[ $labels == 'scheduler-chaos executor no' ]]
labels=$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}} {{index .Config.Labels "com.docker.compose.service"}}' scheduler-chaos-runner)
[[ $labels == 'scheduler-chaos chaos-runner' ]]
docker kill --signal KILL scheduler-chaos-runner > "$probe_dir/fault.txt"
status=0
wait "$harness_pid" || status=$?
[[ $status == 137 ]]
run_dir=$(sed -n 's/^Chaos evidence: \(.*\) (exit 137)$/\1/p' "$probe_dir/host.log")
python3 - "$run_dir" "$victim_id" <<'PY'
import json, pathlib, sys
rows = [json.loads(line) for line in (pathlib.Path(sys.argv[1])/'containers.jsonl').read_text().splitlines()]
victim = next(row for row in rows if row['id'].startswith(sys.argv[2]) or sys.argv[2].startswith(row['id']))
assert victim['restart_policy']['Name'] == 'unless-stopped' and victim['state']['Running']
PY
[[ -z $(docker ps -a -q --filter label=com.docker.compose.project=scheduler-chaos) ]]
[[ -z $(docker volume ls -q --filter label=com.docker.compose.project=scheduler-chaos) ]]
[[ -z $(docker network ls -q --filter label=com.docker.compose.project=scheduler-chaos) ]]
inventory > "$probe_dir/after.txt"
diff -u "$probe_dir/before.txt" "$probe_dir/after.txt"
printf '{"observed_exit":137,"victim":"%s","restart_policy_restored":true,"victim_started":true,"other_stacks_unchanged":true,"chaos_resources_removed":true}\n' "$victim_id" > "$probe_dir/result.json"
tail -n 3 "$probe_dir/host.log"
echo "PASS: killed executor restored after runner loss; evidence in $probe_dir"
