# M8 subset 1 review

Implemented the isolated harness and duplicate-delivery scenario. No production
runtime, schema, public API, SDK, or timing changes were needed. Subsets 2 and 3
have not been implemented; M8 is not complete.

## Changes

- `make chaos` starts one disposable `scheduler-chaos` stack; `CHAOS_COUNT` repeats
  the implemented tests. Two watchers, three executors, durable PostgreSQL, no host
  ports, distinct image tags, and a lock keep it separate from other projects.
- Race-enabled Go tests run inside the network with a Docker CLI. Mutations verify
  Compose project/service labels. The HTTP fixture records calls and supports
  held responses; inspection SQL is available only behind the chaos build tag.
- Duplicate delivery pauses all executors, waits for QUEUED, publishes two more
  copies, then requires one completed HTTP request, one SUCCEEDED attempt, stable
  run/fire identity, and zero Kafka lag.
- Cleanup captures evidence and removes only chaos resources. Shell checks cover
  success, failing tests/builds, interruption, foreign containers, and locking.

## Validation on 2026-10-14

| Check | Result |
| --- | --- |
| Existing unit suite, `go test -race -count=1 ./...` | Passed |
| Fixture and container-scope checks with `-race -tags=chaos` | Passed |
| `bash scripts/chaos_test.sh` | Passed |
| Compose configuration, Bash syntax, `git diff --check` | Passed |
| `make chaos` | Passed |
| Final `make chaos CHAOS_COUNT=2` | Both duplicate tests passed |
| SIGKILL of runner while actual executors were paused | Expected exit 137; host cleanup passed |
| SIGTERM of harness while an actual executor was paused | Expected exit 143; cleanup passed |

Each final duplicate test produced one successful attempt and one HTTP call
with the run ID as its idempotency key. Six metric snapshots were saved per test.
The two cleanup probes verified no remaining chaos containers, volumes, or
network, and byte-identical other-container identity/state inventories before
and afterward. The interrupted runs are intentionally failed runs, not passing
chaos scenarios.

Go compilation and unit checks used `golang:1.26.3-bookworm` because Go is absent
on this host. Existing integration tests were not rerun: production logic is
unchanged, and this subset was exercised against the real Compose services.

## Evidence

[subset1-evidence.tar.gz](subset1-evidence.tar.gz) contains the final two-pass run,
the runner-kill and final SIGTERM runs, cleanup probe records, and shell-check
output. The archive's `checks/lifecycle-probe.sh` reproduces the real cleanup
checks when invoked from the repository root with `kill` or `term`.

Local source directories:

- Successful two-pass run: `results/20261014T155015Z-My5eHF`
- Runner-kill cleanup: `results/20261014T154543Z-dilrwz`
- Final SIGTERM cleanup: `results/20261014T154814Z-aoQk6i`

The implementation also corrects the original plan's two future expectations:
a retried 60-second sleep cannot finish within 20 seconds, and self-fencing need
not increment the stale-completion counter. Existing README and benchmark work
was preserved. Stop here for subset 1 review before implementing executor faults.
