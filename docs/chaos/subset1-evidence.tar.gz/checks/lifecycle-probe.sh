#!/usr/bin/env bash
set -euo pipefail
cd "${CHAOS_REPO:-$PWD}"
[[ -f scripts/chaos.sh && -f docker-compose.chaos.yml ]]
mode=${1:?kill or term}
case "$mode" in kill|term) ;; *) exit 2 ;; esac
probe_dir=$(mktemp -d /tmp/m8-chaos-lifecycle-XXXXXX)
echo "Lifecycle probe: $mode, $probe_dir"
docker ps -a --no-trunc --format '{{.ID}} {{.Names}} {{.State}}' | sort > "$probe_dir/before.txt"
timeout 240 docker events --filter type=container --filter event=pause \
  --filter label=com.docker.compose.project=scheduler-chaos --format '{{.Actor.ID}}' > "$probe_dir/pause.events" &
events_pid=$!
bash scripts/chaos.sh > "$probe_dir/host.log" 2>&1 &
harness_pid=$!
cleanup() {
  trap - EXIT
  kill "$events_pid" 2>/dev/null || true
  if kill -0 "$harness_pid" 2>/dev/null; then
    kill -TERM "$harness_pid" || true
    wait "$harness_pid" || true
  fi
}
trap cleanup EXIT
started=$SECONDS
until [[ -s "$probe_dir/pause.events" ]]; do
  if ! kill -0 "$harness_pid" 2>/dev/null || (( SECONDS - started >= 240 )); then
    tail -n 30 "$probe_dir/host.log"
    exit 1
  fi
  sleep 0.05
done
read -r paused_id < "$probe_dir/pause.events"
labels=$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}} {{index .Config.Labels "com.docker.compose.service"}} {{.State.Paused}}' "$paused_id")
[[ $labels == 'scheduler-chaos executor true' ]]
printf '%s\n' "$labels" > "$probe_dir/fault.txt"
if [[ $mode == kill ]]; then
  labels=$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}} {{index .Config.Labels "com.docker.compose.service"}}' scheduler-chaos-runner)
  [[ $labels == 'scheduler-chaos chaos-runner' ]]
  docker kill --signal KILL scheduler-chaos-runner >> "$probe_dir/fault.txt"
else
  kill -TERM "$harness_pid"
fi
status=0
wait "$harness_pid" || status=$?
if [[ $mode == term ]]; then [[ $status == 143 ]]; else [[ $status == 137 ]]; fi
[[ -z $(docker ps -a -q --filter label=com.docker.compose.project=scheduler-chaos) ]]
[[ -z $(docker volume ls -q --filter label=com.docker.compose.project=scheduler-chaos) ]]
[[ -z $(docker network ls -q --filter label=com.docker.compose.project=scheduler-chaos) ]]
docker ps -a --no-trunc --format '{{.ID}} {{.Names}} {{.State}}' | sort > "$probe_dir/after.txt"
diff -u "$probe_dir/before.txt" "$probe_dir/after.txt"
tail -n 5 "$probe_dir/host.log"
printf '{"probe":"%s","observed_exit":%d,"other_containers_unchanged":true,"chaos_resources_removed":true}\n' "$mode" "$status" > "$probe_dir/result.json"
echo "PASS: $mode cleanup with actual paused executor; evidence in $probe_dir"
